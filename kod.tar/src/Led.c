#include "inc/hw_ints.h"
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "Led.h"
#include "inc/lm4f120h5qr.h"

void Led1_init(void){
	  volatile unsigned long delay;
	  SYSCTL_RCGC2_R |= 0x0000001;      // 1) activate clock for Port A
	  delay = SYSCTL_RCGC2_R;           // allow time for clock to start
	                                    // 2) no need to unlock

	  GPIO_PORTA_PCTL_R &= ~0x00000F00; // 3) regular GPIO
	  GPIO_PORTA_AMSEL_R &= ~0x04;      // 4) disable analog function on PA2
	  GPIO_PORTA_DIR_R |= 0x04;         // 5) set direction to output
	  GPIO_PORTA_AFSEL_R &= ~0x04;      // 6) regular port function
	  GPIO_PORTA_DEN_R |= 0x04;         // 7) enable digital port
}

void Led2_init(void){
	  volatile unsigned long delay;
	  SYSCTL_RCGC2_R |= 0x0000001;      // 1) activate clock for Port A
	  delay = SYSCTL_RCGC2_R;           // allow time for clock to start
	                                    // 2) no need to unlock

	  GPIO_PORTA_PCTL_R &= ~0x0000F000; // 3) regular GPIO
	  GPIO_PORTA_AMSEL_R &= ~0x08;      // 4) disable analog function on PA3
	  GPIO_PORTA_DIR_R |= 0x08;         // 5) set direction to output
	  GPIO_PORTA_AFSEL_R &= ~0x08;      // 6) regular port function
	  GPIO_PORTA_DEN_R |= 0x08;         // 7) enable digital port
}

void Led3_init(void){
	  volatile unsigned long delay;
	  SYSCTL_RCGC2_R |= 0x0000001;      // 1) activate clock for Port A
	  delay = SYSCTL_RCGC2_R;           // allow time for clock to start
	                                    // 2) no need to unlock

	  GPIO_PORTA_PCTL_R &= ~0x000F0000; // 3) regular GPIO
	  GPIO_PORTA_AMSEL_R &= ~0x10;      // 4) disable analog function on PA4
	  GPIO_PORTA_DIR_R |= 0x10;         // 5) set direction to output
	  GPIO_PORTA_AFSEL_R &= ~0x10;      // 6) regular port function
	  GPIO_PORTA_DEN_R |= 0x10;         // 7) enable digital port
}

void Led4_init(void){
	  volatile unsigned long delay;
	  SYSCTL_RCGC2_R |= 0x0000001;      // 1) activate clock for Port A
	  delay = SYSCTL_RCGC2_R;           // allow time for clock to start
	                                    // 2) no need to unlock

	  GPIO_PORTA_PCTL_R &= ~0x00F00000; // 3) regular GPIO
	  GPIO_PORTA_AMSEL_R &= ~0x20;      // 4) disable analog function on PA5
	  GPIO_PORTA_DIR_R |= 0x20;         // 5) set direction to output
	  GPIO_PORTA_AFSEL_R &= ~0x20;      // 6) regular port function
	  GPIO_PORTA_DEN_R |= 0x20;         // 7) enable digital port
}

void Led5_init(void){
	  volatile unsigned long delay;
	  SYSCTL_RCGC2_R |= 0x0000001;      // 1) activate clock for Port A
	  delay = SYSCTL_RCGC2_R;           // allow time for clock to start
	                                    // 2) no need to unlock

	  GPIO_PORTA_PCTL_R &= ~0x0F000000; // 3) regular GPIO
	  GPIO_PORTA_AMSEL_R &= ~0x40;      // 4) disable analog function on PA6
	  GPIO_PORTA_DIR_R |= 0x40;         // 5) set direction to output
	  GPIO_PORTA_AFSEL_R &= ~0x40;      // 6) regular port function
	  GPIO_PORTA_DEN_R |= 0x40;         // 7) enable digital port
}

void Led6_init(void){
	  volatile unsigned long delay;
	  SYSCTL_RCGC2_R |= 0x0000001;      // 1) activate clock for Port A
	  delay = SYSCTL_RCGC2_R;           // allow time for clock to start
	                                    // 2) no need to unlock
	  GPIO_PORTA_PCTL_R &= ~0xF0000000; // 3) regular GPIO
	  GPIO_PORTA_AMSEL_R &= ~0x80;      // 4) disable analog function on PA7
	  GPIO_PORTA_DIR_R |= 0x80;         // 5) set direction to output
	  GPIO_PORTA_AFSEL_R &= ~0x80;      // 6) regular port function
	  GPIO_PORTA_DEN_R |= 0x80;         // 7) enable digital port
}

void Led7_init(void){
	  volatile unsigned long delay;
	  SYSCTL_RCGC2_R |= 0x0000020;      // 1) activate clock for Port F
	  delay = SYSCTL_RCGC2_R;           // allow time for clock to start
	                                    // 2) no need to unlock

	  GPIO_PORTF_PCTL_R &= ~0x000000F0; // 3) regular GPIO
	  GPIO_PORTF_AMSEL_R &= ~0x02;      // 4) disable analog function on PF1
	  GPIO_PORTF_DIR_R |= 0x02;         // 5) set direction to output
	  GPIO_PORTF_AFSEL_R &= ~0x02;      // 6) regular port function
	  GPIO_PORTF_DEN_R |= 0x02;         // 7) enable digital port
}

void Led1Blinky(void){GPIO_PORTA_DATA_R |= 0x04;}
void Led2Blinky(void){GPIO_PORTA_DATA_R |= 0x08;}
void Led3Blinky(void){GPIO_PORTA_DATA_R |= 0x10;}
void Led4Blinky(void){GPIO_PORTA_DATA_R |= 0x20;}
void Led5Blinky(void){GPIO_PORTA_DATA_R |= 0x40;}
void Led6Blinky(void){GPIO_PORTA_DATA_R |= 0x80;}
void Led7Blinky(void){GPIO_PORTF_DATA_R |= 0x02;}

void Led1Off(void){GPIO_PORTA_DATA_R &= ~0x04;}
void Led2Off(void){GPIO_PORTA_DATA_R &= ~0x08;}
void Led3Off(void){GPIO_PORTA_DATA_R &= ~0x10;}
void Led4Off(void){GPIO_PORTA_DATA_R &= ~0x20;}
void Led5Off(void){GPIO_PORTA_DATA_R &= ~0x40;}
void Led6Off(void){GPIO_PORTA_DATA_R &= ~0x80;}
void Led7Off(void){GPIO_PORTF_DATA_R &= ~0x02;}


