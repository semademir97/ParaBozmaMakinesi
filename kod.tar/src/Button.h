#ifndef BUTTON_H_
#define BUTTON_H_


#define PD0   (GPIO_PORTD_DATA_R&0x01) //Button1
#define PD1   (GPIO_PORTD_DATA_R&0x02) //Button2
#define PD2   (GPIO_PORTD_DATA_R&0x04) //Button3
#define PD3   (GPIO_PORTD_DATA_R&0x08) //Button4
#define PD6   (GPIO_PORTD_DATA_R&0x40) //Button5
#define PC4   (GPIO_PORTC_DATA_R&0x10) //Button6
#define PC5   (GPIO_PORTC_DATA_R&0x20) //Button7


unsigned long Button1Pressed(void);
unsigned long Button2Pressed(void);
unsigned long Button3Pressed(void);
unsigned long Button4Pressed(void);
unsigned long Button5Pressed(void);
unsigned long Button6Pressed(void);
unsigned long Button7Pressed(void);




#endif /* BUTTON_H_ */
