
#include "inc/hw_ints.h"
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Lcd.h"
#include "Button.h"
#include "Led.h"
#include "inc/lm4f120h5qr.h"

void init_function(void){
	Button1_init();
	Button2_init();
	Button3_init();
	Button4_init();
	Button5_init();
	Button6_init();
	Button7_init();
	Led1_init();
	Led2_init();
	Led3_init();
	Led4_init();
	Led5_init();
	Led6_init();
	Led7_init();
	Lcd_init();

}
volatile unsigned long delay;
int main(void) {
	int i=0;
    init_function();
    int count =0;
    int sonuc=0;
    int onlar=0;
    int birler=0;
    int yarimlar=0;
    int ceyrekler=0;
    int k=0;
    char buffer[100];
    Lcd_Goto(1,1);
    Lcd_Puts("TL Bozma makinesi");
    for(delay=0;delay<=600000;delay++);
    Lcd_Temizle();
	while(1){
		 if(Button1Pressed()){
			 count++;
			Led1Blinky();
			for(delay=0;delay<=200000;delay++);
			onlar%=10;
			if(onlar%10!=0)
			sonuc+=1000;
			itoa(onlar,buffer,10);
			onlar+=1;
		    Lcd_Goto(1,12);
			Lcd_Puts(buffer);
			Lcd_Goto(1,1);
	   }

	   if(Button2Pressed()){
		   count++;
			Led2Blinky();
			for(delay=0;delay<=200000;delay++);
			birler%=10;
			if(birler%10!=0){
				sonuc+=100;
			}
			itoa(birler,buffer,10);
			birler+=1;
			Lcd_Goto(1,13);
			Lcd_Puts(buffer);
			Lcd_Goto(1,1);

	    }
		if(Button3Pressed()){
			count++;
			i++;
			if(i==4){
				Led3Blinky();
				for(delay=0;delay<=200000;delay++);
				count =0;
				sonuc=0;
				onlar=0;
				birler=0;
				yarimlar=0;
				ceyrekler=0;
				Lcd_Temizle();
				Lcd_Goto(1,1);
				i=0;
			}
			Led3Blinky();
			for(delay=0;delay<=200000;delay++);
			Lcd_Goto(1,14);
			Lcd_Puts(".");
			Lcd_Goto(1,1);
		}
		if(Button4Pressed()){
			count++;
			Led4Blinky();
			for(delay=0;delay<=200000;delay++);
			yarimlar%=10;
			if(yarimlar%10!=0)
			sonuc+=10;
			itoa(yarimlar,buffer,10);
			yarimlar+=1;
			Lcd_Goto(1,15);
			Lcd_Puts(buffer);
			Lcd_Goto(1,1);
	    }
		if(Button5Pressed()){
			count++;
			Led5Blinky();
			for(delay=0;delay<=200000;delay++);
			ceyrekler%=10;
			if(ceyrekler%10!=0)
			sonuc+=1;
			itoa(ceyrekler,buffer,10);
			ceyrekler+=1;
			Lcd_Goto(1,16);
			Lcd_Puts(buffer);
			Lcd_Goto(1,1);
	    }
		if(Button6Pressed()){
			count++;
			Led6Blinky();
			parayi_boz(sonuc);
	    }
		if(Button7Pressed()){
			count++;
			Led7Blinky();
			for(delay=0;delay<=200000;delay++);
		    count =0;
		    sonuc=0;
		    onlar=0;
		    birler=0;
		    yarimlar=0;
		    ceyrekler=0;
			Lcd_Temizle();
			Lcd_Goto(1,1);
		}
		else{

			Led1Off();
			Led2Off();
			Led3Off();
			Led4Off();
			Led5Off();
			Led6Off();
			Led7Off();

			for(delay=0;delay<=200000;delay++);
			if(count>=1){
			k++;
			if(k==20){
				parayi_boz(sonuc);
			}
			}
		}
	}

}
void saga_yazdir(int a){
	int sonuc;
	char buffer[20];
	Lcd_Goto(1,1);
	Lcd_Puts("                ");
	sonuc = a%10;
	a/=10;
	itoa(sonuc,buffer,10);
	Lcd_Goto(1,16);
	Lcd_Puts(buffer);

	sonuc = a%10;
	a/=10;
	itoa(sonuc,buffer,10);
	Lcd_Goto(1,15);
	Lcd_Puts(buffer);

	Lcd_Goto(1,14);
	Lcd_Puts(".");

	sonuc = a%10;
	a/=10;
	itoa(sonuc,buffer,10);
	Lcd_Goto(1,13);
	Lcd_Puts(buffer);

	sonuc = a%10;
	a/=10;
	itoa(sonuc,buffer,10);
	Lcd_Goto(1,12);
	Lcd_Puts(buffer);

}
void parayi_boz(int a){
	int yirmilik=0,onluk=0,beslikler=0,birlikler=0,yarimlik=0,ceyreklik=0,delik=0,kurus=0;
				for(delay=0;delay<=200000;delay++);
				char buffer[20];

				yirmilik=a/2000;
				itoa(yirmilik,buffer,10);
				Lcd_Goto(2,1);
							Lcd_Puts(buffer);
							Lcd_Goto(2,3);
							Lcd_Puts("tane yirmilik");
				for(delay=0;delay<=2000000;delay++);
				a-=(yirmilik*2000);
				Lcd_Puts("                ");
				saga_yazdir(a);

				onluk=a/1000;
				itoa(onluk,buffer,10);
				Lcd_Goto(2,1);
							Lcd_Puts(buffer);
							Lcd_Goto(2,3);
							Lcd_Puts("tane onluk");
				for(delay=0;delay<=2000000;delay++);
				a-=(onluk*1000);
				Lcd_Puts("                ");
				saga_yazdir(a);
				beslikler=a/500;
				itoa(beslikler,buffer,10);
				Lcd_Goto(2,1);
							Lcd_Puts(buffer);
							Lcd_Goto(2,3);
							Lcd_Puts("tane beslik");
				for(delay=0;delay<=2000000;delay++);
				a-=(beslikler*500);
				Lcd_Puts("                ");
				saga_yazdir(a);

				birlikler=a/100;
				itoa(birlikler,buffer,10);
				Lcd_Goto(2,1);
							Lcd_Puts(buffer);
							Lcd_Goto(2,3);
							Lcd_Puts(" tane birlik");
				for(delay=0;delay<=2000000;delay++);
				a-=(birlikler*100);
				Lcd_Puts("                ");
				saga_yazdir(a);

				yarimlik=a/50;
				itoa(yarimlik,buffer,10);
				Lcd_Goto(2,1);
							Lcd_Puts(buffer);
							Lcd_Goto(2,3);
							Lcd_Puts("tane yarimlik");
				for(delay=0;delay<=2000000;delay++);
				a-=(yarimlik*50);
				Lcd_Puts("                ");
				saga_yazdir(a);

				ceyreklik=a/25;
				itoa(ceyreklik,buffer,10);
				Lcd_Goto(2,1);
				Lcd_Puts(buffer);
				Lcd_Goto(2,3);
				Lcd_Puts("tane ceyreklik");
				for(delay=0;delay<=2000000;delay++);
				a-=(ceyreklik*25);
				Lcd_Puts("                ");
				saga_yazdir(a);

				delik=a/10;
				itoa(delik,buffer,10);
				Lcd_Goto(2,1);
				Lcd_Puts(buffer);
				Lcd_Goto(2,3);
				Lcd_Puts("tane delik");
				for(delay=0;delay<=2000000;delay++);
				a-=(delik*10);
				Lcd_Puts("                ");
				saga_yazdir(a);

				kurus=a/1;
				itoa(kurus,buffer,10);
				Lcd_Goto(2,1);
				Lcd_Puts(buffer);
				Lcd_Goto(2,3);
				Lcd_Puts("tane kurusluk");
				for(delay=0;delay<=2000000;delay++);
				a-=(kurus*1);
				Lcd_Puts("                ");
				saga_yazdir(a);
}
