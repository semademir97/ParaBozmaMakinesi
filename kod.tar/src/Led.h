#ifndef LED_H_
#define LED_H_

void Led1Blinky(void);
void Led2Blinky(void);
void Led3Blinky(void);
void Led4Blinky(void);
void Led5Blinky(void);
void Led6Blinky(void);
void Led7Blinky(void);

void Led1Off(void);
void Led2Off(void);
void Led3Off(void);
void Led4Off(void);
void Led5Off(void);
void Led6Off(void);
void Led7Off(void);

#endif /* LED_H_ */
